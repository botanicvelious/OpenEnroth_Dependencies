/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.28.0-116-g10135b2d7 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.28.0-116-g10135b2d7"
#endif
